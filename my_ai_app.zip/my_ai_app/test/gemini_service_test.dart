import 'package:flutter_test/flutter_test.dart';
import 'package:my_ai_app/core/config/app_config.dart';
import 'package:my_ai_app/features/chat/data/datasources/gemini_remote_service.dart';

void main() {
  test('Gemini returns text for hello prompt', () async {
    if (!AppConfig.hasValidApiKey) {
      return;
    }

    final service = GeminiRemoteService(apiKey: AppConfig.geminiApiKey);
    service.initializeSession(const []);

    final chunks = <String>[];
    await for (final chunk in service.sendMultimodalMessageStream(
      prompt: 'Reply with exactly: OK',
      attachmentPaths: const [],
    )) {
      chunks.add(chunk);
    }

    final full = chunks.join();
    expect(full.trim().isNotEmpty, isTrue);
  }, timeout: const Timeout(Duration(minutes: 2)));
}
