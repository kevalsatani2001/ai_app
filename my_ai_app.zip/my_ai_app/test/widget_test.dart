import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:my_ai_app/core/genai/genai_content.dart';
import 'package:my_ai_app/features/chat/domain/entities/chat_message.dart';

void main() {
  test('ChatMessage supports media paths', () {
    final message = ChatMessage(
      id: '1',
      role: 'user',
      text: 'Check this',
      timestamp: DateTime(2026, 5, 19),
      mediaPaths: const ['/tmp/photo.jpg'],
    );

    expect(message.hasMedia, isTrue);
    expect(message.mediaPaths, hasLength(1));
  });

  test('GenAiContent.multi builds multimodal JSON', () {
    final content = GenAiContent.multi([
      GenAiTextPart('Hello'),
      GenAiData.mime('image/jpeg', Uint8List.fromList([1, 2, 3])),
    ]);

    final json = content.toJson();
    expect(json['role'], 'user');
    expect(json['parts'], hasLength(2));
  });
}
