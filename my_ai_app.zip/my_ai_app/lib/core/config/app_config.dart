class AppConfig {
  AppConfig._();

  static const String geminiModel = 'gemini-2.5-flash';

  static const String hiveChatBoxName = 'chat_messages_multimodal_box';

  static const int chatMessageTypeId = 1;

  static const int maxAttachmentBytes = 20 * 1024 * 1024;

  static const List<String> allowedImageExtensions = [
    'jpg',
    'jpeg',
    'png',
    'webp',
    'gif',
    'heic',
  ];

  static const List<String> allowedPdfExtensions = ['pdf'];

  /// Override at run time:
  /// flutter run --dart-define=GEMINI_API_KEY=your_key_here
  static const String geminiApiKey = String.fromEnvironment(
    'GEMINI_API_KEY',
    defaultValue: 'AIzaSyBq1mepssvlYqi51BB1LkCpzYpaBqImlNc',
  );

  static bool get hasValidApiKey => geminiApiKey.trim().isNotEmpty;

}
