import 'dart:async';
import 'dart:io';

import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:my_ai_app/core/config/app_config.dart';
import 'package:my_ai_app/core/error/failures.dart';
import 'package:my_ai_app/core/services/attachment_storage_service.dart';
import 'package:my_ai_app/features/chat/domain/entities/chat_message.dart';

/// Reliable Gemini integration: [GenerativeModel.generateContent] for the
/// full reply, then word-by-word emission so the UI still streams smoothly.
class GeminiRemoteService {
  GeminiRemoteService({
    required String apiKey,
    String modelName = AppConfig.geminiModel,
    Duration requestTimeout = const Duration(seconds: 120),
  })  : _apiKey = apiKey,
        _modelName = modelName,
        _requestTimeout = requestTimeout {
    _model = GenerativeModel(
      model: _modelName,
      apiKey: _apiKey,
      generationConfig: GenerationConfig(
        temperature: 0.8,
        topP: 0.95,
        maxOutputTokens: 8192,
      ),
    );
  }

  final String _apiKey;
  final String _modelName;
  final Duration _requestTimeout;

  late final GenerativeModel _model;
  List<ChatMessage> _sessionHistory = const [];

  void initializeSession(List<ChatMessage> history) {
    _sessionHistory = List<ChatMessage>.from(
      history.where((m) => m.text.trim().isNotEmpty || m.hasMedia),
    );
  }

  Stream<String> sendMultimodalMessageStream({
    required String prompt,
    required List<String> attachmentPaths,
  }) async* {
    if (_apiKey.trim().isEmpty) {
      throw const ApiFailure(
        'Gemini API key is missing. Check AppConfig.geminiApiKey.',
      );
    }

    final userContent = await _buildSdkMessage(
      prompt: prompt,
      attachmentPaths: attachmentPaths,
    );

    final contents = <Content>[
      for (final message in _sessionHistory) _toSdkContent(message),
      userContent,
    ];

    final fullText = await _generateOnce(contents);

    if (fullText.trim().isEmpty) {
      throw const ApiFailure(
        'Gemini returned an empty response. Please try again.',
      );
    }

    final words = fullText.split(RegExp(r'(\s+)'));
    for (final word in words) {
      if (word.isEmpty) {
        continue;
      }
      yield word;
      await Future<void>.delayed(const Duration(milliseconds: 12));
    }
  }

  Future<String> _generateOnce(List<Content> contents) async {
    try {
      final response =
          await _model.generateContent(contents).timeout(_requestTimeout);
      final text = _safeResponseText(response);
      if (text != null && text.isNotEmpty) {
        return text;
      }
      throw const ApiFailure('Gemini response had no readable text.');
    } catch (error) {
      throw _mapException(error);
    }
  }

  Future<Content> _buildSdkMessage({
    required String prompt,
    required List<String> attachmentPaths,
  }) async {
    final parts = <Part>[];

    final trimmed = prompt.trim();
    if (trimmed.isNotEmpty) {
      parts.add(TextPart(trimmed));
    } else if (attachmentPaths.isNotEmpty) {
      parts.add(
        TextPart(
          'Analyze the attached file(s) and provide a detailed, helpful response.',
        ),
      );
    }

    for (final path in attachmentPaths) {
      final file = File(path);
      if (!await file.exists()) {
        throw UnknownFailure('Attachment not found: $path');
      }
      final bytes = await file.readAsBytes();
      if (bytes.length > AppConfig.maxAttachmentBytes) {
        throw UnknownFailure(
          'Attachment exceeds ${AppConfig.maxAttachmentBytes ~/ (1024 * 1024)} MB.',
        );
      }
      final mime = AttachmentStorageService.mimeTypeForPath(path);
      parts.add(DataPart(mime, bytes));
    }

    if (parts.isEmpty) {
      throw const UnknownFailure('Message must include text or an attachment.');
    }

    return Content.multi(parts);
  }

  Content _toSdkContent(ChatMessage message) {
    if (message.isUser && message.hasMedia) {
      final parts = <Part>[];
      if (message.text.trim().isNotEmpty) {
        parts.add(TextPart(message.text));
      }
      for (final path in message.mediaPaths) {
        final file = File(path);
        if (file.existsSync()) {
          parts.add(
            DataPart(
              AttachmentStorageService.mimeTypeForPath(path),
              file.readAsBytesSync(),
            ),
          );
        }
      }
      return Content.multi(parts);
    }

    if (message.isUser) {
      return Content.text(message.text);
    }

    return Content.model([TextPart(message.text)]);
  }

  String? _safeResponseText(GenerateContentResponse response) {
    try {
      final text = response.text;
      if (text != null && text.isNotEmpty) {
        return text;
      }
    } catch (_) {}

    final buffer = StringBuffer();
    for (final candidate in response.candidates) {
      for (final part in candidate.content.parts) {
        if (part is TextPart && part.text.isNotEmpty) {
          buffer.write(part.text);
        }
      }
    }

    return buffer.isEmpty ? null : buffer.toString();
  }

  Failure _mapException(Object error) {
    if (error is Failure) {
      return error;
    }

    final message = error.toString().toLowerCase();

    if (error is TimeoutException ||
        message.contains('timeout') ||
        message.contains('deadline')) {
      return const TimeoutFailure(
        'Gemini response timed out. Please try again.',
      );
    }

    if (error is SocketException ||
        message.contains('socket') ||
        message.contains('network') ||
        message.contains('connection')) {
      return const NetworkFailure(
        'Network connection lost. Check your internet and retry.',
      );
    }

    if (message.contains('429') ||
        message.contains('quota') ||
        message.contains('rate limit')) {
      return const RateLimitFailure(
        'API rate limit reached. Please wait and try again.',
      );
    }

    if (message.contains('401') ||
        message.contains('403') ||
        message.contains('api key') ||
        message.contains('leaked')) {
      return ApiFailure(
        message.contains('leaked')
            ? 'API key blocked. New key: https://aistudio.google.com/apikey'
            : 'Invalid API key. Check AppConfig.geminiApiKey.',
      );
    }

    return UnknownFailure('Gemini error: $error');
  }

  void dispose() {}
}
