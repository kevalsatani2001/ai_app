import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:my_ai_app/core/error/failures.dart';
import 'package:my_ai_app/core/services/attachment_storage_service.dart';
import 'package:my_ai_app/features/chat/domain/entities/chat_message.dart';
import 'package:my_ai_app/features/chat/domain/repositories/chat_repository.dart';
import 'package:my_ai_app/features/chat/presentation/bloc/chat_event.dart';
import 'package:my_ai_app/features/chat/presentation/bloc/chat_state.dart';
import 'package:uuid/uuid.dart';

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  ChatBloc({
    required ChatRepository repository,
    required AttachmentStorageService attachmentStorage,
    Uuid uuid = const Uuid(),
  })  : _repository = repository,
        _attachmentStorage = attachmentStorage,
        _uuid = uuid,
        super(const ChatInitial()) {
    on<LoadChatHistory>(_onLoadChatHistory);
    on<PickAttachment>(_onPickAttachment);
    on<RemoveSelectedAttachment>(_onRemoveSelectedAttachment);
    on<SendMultimodalPrompt>(_onSendMultimodalPrompt);
    on<ClearChatError>(_onClearChatError);
    on<ClearChatHistory>(_onClearChatHistory);
  }

  final ChatRepository _repository;
  final AttachmentStorageService _attachmentStorage;
  final Uuid _uuid;

  List<ChatMessage> _messages = const [];

  Future<void> _onLoadChatHistory(
    LoadChatHistory event,
    Emitter<ChatState> emit,
  ) async {
    emit(const ChatHistoryLoading());
    try {
      _messages = await _repository.loadChatHistory();
      emit(
        ChatStateActive(
          messages: List<ChatMessage>.unmodifiable(_messages),
        ),
      );
    } on Failure catch (failure) {
      emit(
        ChatStateActive(
          messages: const [],
          errorMessage: failure.message,
        ),
      );
    } catch (error) {
      emit(
        ChatStateActive(
          messages: const [],
          errorMessage: 'Unable to load chat history: $error',
        ),
      );
    }
  }

  Future<void> _onPickAttachment(
    PickAttachment event,
    Emitter<ChatState> emit,
  ) async {
    final currentState = state;
    if (currentState is! ChatStateActive || currentState.isStreaming) {
      return;
    }

    try {
      final picked = await _attachmentStorage.pickAttachments(event.type);
      if (picked.isEmpty) {
        return;
      }

      emit(
        currentState.copyWith(
          selectedFiles: [...currentState.selectedFiles, ...picked],
          clearError: true,
        ),
      );
    } on Failure catch (failure) {
      emit(currentState.copyWith(errorMessage: failure.message));
    } catch (error) {
      emit(
        currentState.copyWith(
          errorMessage: 'Failed to pick attachment: $error',
        ),
      );
    }
  }

  void _onRemoveSelectedAttachment(
    RemoveSelectedAttachment event,
    Emitter<ChatState> emit,
  ) {
    final currentState = state;
    if (currentState is! ChatStateActive) {
      return;
    }

    emit(
      currentState.copyWith(
        selectedFiles: currentState.selectedFiles
            .where((file) => file.path != event.filePath)
            .toList(),
      ),
    );
  }

  Future<void> _onSendMultimodalPrompt(
    SendMultimodalPrompt event,
    Emitter<ChatState> emit,
  ) async {
    final currentState = state;
    if (currentState is! ChatStateActive || currentState.isStreaming) {
      return;
    }

    final trimmedPrompt = event.text.trim();
    final hasAttachments = currentState.selectedFiles.isNotEmpty;

    if (trimmedPrompt.isEmpty && !hasAttachments) {
      return;
    }

    final mediaPaths =
        currentState.selectedFiles.map((file) => file.path).toList();

    final userMessage = ChatMessage(
      id: _uuid.v4(),
      role: 'user',
      text: trimmedPrompt,
      timestamp: DateTime.now(),
      mediaPaths: mediaPaths,
    );

    final modelMessageId = _uuid.v4();

    try {
      await _repository.saveMessage(userMessage);
    } on Failure catch (failure) {
      emit(currentState.copyWith(errorMessage: failure.message));
      return;
    } catch (error) {
      emit(
        currentState.copyWith(
          errorMessage: 'Failed to save your message: $error',
        ),
      );
      return;
    }

    _messages = [
      ..._messages,
      userMessage,
      ChatMessage(
        id: modelMessageId,
        role: 'model',
        text: '',
        timestamp: DateTime.now(),
      ),
    ];

    emit(
      ChatStateActive(
        messages: List<ChatMessage>.unmodifiable(_messages),
        selectedFiles: const [],
        isStreaming: true,
        streamingMessageId: modelMessageId,
        errorMessage: null,
      ),
    );

    final priorHistory = List<ChatMessage>.from(_messages)
      ..removeWhere((m) => m.id == modelMessageId)
      ..removeWhere((m) => m.id == userMessage.id);

    try {
      final stream = _repository.sendMultimodalStream(
        prompt: trimmedPrompt,
        history: priorHistory,
        attachmentPaths: mediaPaths,
      );

      await for (final chunk in stream) {
        final index = _messages.indexWhere((m) => m.id == modelMessageId);
        if (index == -1) {
          continue;
        }

        _messages = List<ChatMessage>.from(_messages);
        _messages[index] = _messages[index].copyWith(
          text: _messages[index].text + chunk,
        );

        emit(
          ChatStateActive(
            messages: List<ChatMessage>.unmodifiable(_messages),
            selectedFiles: const [],
            isStreaming: true,
            streamingMessageId: modelMessageId,
          ),
        );
      }

      await _finalizeModelMessage(emit, modelMessageId);
    } catch (error) {
      _messages = List<ChatMessage>.from(_messages)
        ..removeWhere((m) => m.id == modelMessageId);

      final message =
          error is Failure ? error.message : 'Request failed: $error';

      emit(
        ChatStateActive(
          messages: List<ChatMessage>.unmodifiable(_messages),
          isStreaming: false,
          errorMessage: message,
        ),
      );
    }
  }

  Future<void> _finalizeModelMessage(
    Emitter<ChatState> emit,
    String modelMessageId,
  ) async {
    final index = _messages.indexWhere((m) => m.id == modelMessageId);
    if (index == -1) {
      emit(
        ChatStateActive(
          messages: List<ChatMessage>.unmodifiable(_messages),
          isStreaming: false,
        ),
      );
      return;
    }

    final finalized = _messages[index];

    if (finalized.text.trim().isEmpty) {
      _messages = List<ChatMessage>.from(_messages)..removeAt(index);
      emit(
        ChatStateActive(
          messages: List<ChatMessage>.unmodifiable(_messages),
          isStreaming: false,
          errorMessage:
              'Gemini returned no text. Please fully restart the app (not hot reload).',
        ),
      );
      return;
    }

    try {
      await _repository.saveMessage(finalized);
    } on Failure catch (failure) {
      emit(
        ChatStateActive(
          messages: List<ChatMessage>.unmodifiable(_messages),
          isStreaming: false,
          errorMessage: failure.message,
        ),
      );
      return;
    }

    emit(
      ChatStateActive(
        messages: List<ChatMessage>.unmodifiable(_messages),
        isStreaming: false,
        streamingMessageId: null,
      ),
    );
  }

  void _onClearChatError(
    ClearChatError event,
    Emitter<ChatState> emit,
  ) {
    final currentState = state;
    if (currentState is ChatStateActive) {
      emit(currentState.copyWith(clearError: true));
    }
  }

  Future<void> _onClearChatHistory(
    ClearChatHistory event,
    Emitter<ChatState> emit,
  ) async {
    try {
      await _repository.clearChatHistory();
      _messages = const [];
      emit(
        const ChatStateActive(
          messages: [],
          isStreaming: false,
        ),
      );
    } on Failure catch (failure) {
      emit(
        _activeStateOrEmpty().copyWith(errorMessage: failure.message),
      );
    } catch (error) {
      emit(
        _activeStateOrEmpty().copyWith(
          errorMessage: 'Failed to clear chat history: $error',
        ),
      );
    }
  }

  ChatStateActive _activeStateOrEmpty() {
    final currentState = state;
    if (currentState is ChatStateActive) {
      return currentState;
    }
    return ChatStateActive(messages: List<ChatMessage>.unmodifiable(_messages));
  }
}
